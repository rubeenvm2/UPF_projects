#include "application.h"
#include "utils.h"
#include "image.h"
#include "mesh.h"


Application::Application(const char* caption, int width, int height)
{
	this->window = createWindow(caption, width, height);

	// initialize attributes
	// Warning: DO NOT CREATE STUFF HERE, USE THE INIT 
	// things create here cannot access opengl
	int w,h;
	SDL_GetWindowSize(window,&w,&h);

	this->window_width = w;
	this->window_height = h;
	this->keystate = SDL_GetKeyboardState(NULL);

	zbuffer.resize(w, h);
	framebuffer.resize(w, h);
}

//Here we have already GL working, so we can create meshes and textures
//Here we have already GL working, so we can create meshes and textures
void Application::init(void)
{
	std::cout << "initiating app..." << std::endl;
	
	//here we create a global camera and set a position and projection properties
	camera = new Camera();
	camera->lookAt(Vector3(0,10,20),Vector3(0,10,0),Vector3(0,1,0)); //define eye,center,up
	camera->perspective(60, window_width / (float)window_height, 0.1, 10000); //define fov,aspect,near,far

	//load a mesh
	mesh = new Mesh();
	if( !mesh->loadOBJ("lee.obj") )
		std::cout << "FILE Lee.obj NOT FOUND" << std::endl;

	//load the texture
	texture = new Image();
	texture->loadTGA("color.tga");
	//Inicializamos el zbuffer poniendo los valores de todos los pixeles a un valor muy alto.
	for( int i = 0; i < window_width; i++) {
		for (int j = 0; j < window_height; j++) {
			zbuffer.setPixel(i, j, 10000000000000);
		}
	}
}

//this function fills the triangle by computing the bounding box of the triangle in screen space and using the barycentric interpolation
//to check which pixels are inside the triangle. It is slow for big triangles, but faster for small triangles 
void Application::fillTriangle(const Vector3& p0, const Vector3& p1, const Vector3& p2, const Vector2& uv0, const Vector2& uv1, const Vector2& uv2)
{
	//compute triangle bounding box in screen space
	Vector3 min;
	Vector3 max;
	for (int i = 0; i < 3; i++) {
		if (p0.v[i] <= p1.v[i] && p0.v[i] <= p2.v[i]) {
			min.v[i] = p0.v[i];
			if (p1.v[i] < p2.v[i]) {
				max.v[i] = p2.v[i];
			}
			else {
				max.v[i] = p1.v[i];
			}
		}
		else if(p1.v[i] < p0.v[i] && p1.v[i] <= p2.v[i]) {
			min.v[i] = p1.v[i];
			if (p0.v[i] < p2.v[i]) {
				max.v[i] = p2.v[i];
			}
			else {
				max.v[i] = p0.v[i];
			}
		}
		else if (p2.v[i] < p0.v[i] && p2.v[i] < p1.v[i]) {
			min.v[i] = p2.v[i];
			if (p0.v[i] < p1.v[i]) {
				max.v[i] = p1.v[i];
			}
			else {
				max.v[i] = p0.v[i];
			}
		}
	}

	//clamp to screen area
	min.x = clamp(min.x, 0, window_width - 1);
	min.y = clamp(min.y, 0, window_height - 1);
	min.z = clamp(min.z, -1, 1);	
	max.x = clamp(max.x, 0, window_width - 1);
	max.y = clamp(max.y, 0, window_height - 1);
	max.z = clamp(max.z, -1, 1);

	Vector3 v0 = p1 - p0;
	Vector3 v1 = p2 - p0;
	Vector3 v2;
	float d00 = v0.dot(v0);
	float d01 = v0.dot(v1);
	float d11 = v1.dot(v1);
	//Como se hizo en la practica 3, vamos desde la minima x e y de la bounding box hasta sus maximos y calculamos los coeficientes u,v,w de cada pixel de la bounding box.
	for (int i = min.x; i < max.x; i++) {
		for (int j = min.y; j < max.y; j++) {
			v2.x = i - p0.x;
			v2.y = j - p0.y;
			float d20 = v2.dot(v0);
			float d21 = v2.dot(v1);
			float denom = d00 * d11 - d01 * d01;
			float v = (d11 * d20 - d01 * d21) / denom;
			float w = (d00 * d21 - d01 * d20) / denom;
			float u = 1.0 - v - w;
			if (u < 0 || u > 1 || v < 0 || v > 1 || w < 0 || w > 1) {
				continue;
			}
			//Hacemos la interpolaci�n de los colores RGB para cada pixel segun sus coeficientes u,v,w.
			Color c = Color::RED * u + Color::GREEN * v + Color::BLUE * w;
			//Hacemos la interpolaci�n de los valores z para cada pixel segun sus coeficientes u,v,w.
			float value = p0.z * u + p1.z * v + p2.z * w;
			//Hacemos la interpolaci�n de las coordenadas de textura para cada pixel segun sus coeficientes u,v,w.
			Vector2 texture_coords = uv0 * u + uv1 * v + uv2 * w;
			//Cogemos el Color de la textura en el pixel en coordenadas de textura
			Color text = texture->getPixel(texture_coords.x, texture_coords.y);
			//Miramos por oclusi�n si el valor de z de ese pixel es menor al que ya estaba en ese punto i,j del plano 2d.
			if (value < zbuffer.getPixel(i,j)) {
				framebuffer.setPixel(i, j, text);
				//Actualizamos el zbuffer.
				zbuffer.setPixel(i, j, value);
			}

		}
	}

}

//render one frame
void Application::render(Image& framebuffer)
{
	framebuffer.fill(Color(40, 45, 60)); //clear
	zbuffer.fill(100000000);

	//for every point of the mesh (to draw triangles take three points each time and connect the points between them (1,2,3,   4,5,6,   ...)
	for (int i = 0; i < mesh->vertices.size(); i = i+3)
	{
		Vector3 vertex0 = mesh->vertices[i]; //extract vertex from mesh
		Vector3 vertex1 = mesh->vertices[i+1]; //extract vertex from mesh
		Vector3 vertex2 = mesh->vertices[i+2]; //extract vertex from mesh
		Vector2 texcoord0 = mesh->uvs[i]; 
		Vector2 texcoord1 = mesh->uvs[i+1]; 
		Vector2 texcoord2 = mesh->uvs[i+2]; //texture coordinate of the vertex (they are normalized, from 0,0 to 1,1)
		//Pasamos las coordenadas de textura de 0,1 a la width y la height de las texturas.
		texcoord0.x = (texcoord0.x) * texture->width;
		texcoord0.y = (texcoord0.y) * texture->height;
		texcoord1.x = (texcoord1.x) * texture->width;
		texcoord1.y = (texcoord1.y) * texture->height;
		texcoord2.x = (texcoord2.x) * texture->width;
		texcoord2.y = (texcoord2.y) * texture->height;

		//project every point in the mesh to normalized coordinates using the viewprojection_matrix inside camera
		Vector3 normalized_point0 = camera->projectVector(vertex0);
		Vector3 normalized_point1 = camera->projectVector(vertex1);
		Vector3 normalized_point2 = camera->projectVector(vertex2);



		//convert from normalized (-1 to +1) to framebuffer coordinates (0,W)
		normalized_point0.x = (normalized_point0.x + 1) * window_width / 2;
		normalized_point0.y = (normalized_point0.y + 1) * window_height / 2;
		normalized_point1.x = (normalized_point1.x + 1) * window_width / 2;
		normalized_point1.y = (normalized_point1.y + 1) * window_height / 2;
		normalized_point2.x = (normalized_point2.x + 1) * window_width / 2;
		normalized_point2.y = (normalized_point2.y + 1) * window_height / 2;



		//paint points in framebuffer (using your drawTriangle function or the fillTriangle function)
		switch (render_mode)
		{
		case 1:
			framebuffer.Triangle(normalized_point0.x, normalized_point0.y, normalized_point1.x, normalized_point1.y, normalized_point2.x, normalized_point2.y, Color::WHITE);
			break;
		case 2:
			fillTriangle(normalized_point0, normalized_point1, normalized_point2, texcoord0, texcoord1, texcoord2);
			break;
		}
	}
}

//called after render
void Application::update(double seconds_elapsed)
{

	if (keystate[SDL_SCANCODE_LEFT])
		camera->eye.x -= 7 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_RIGHT])
		camera->eye.x += 7 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_W])
		camera->center.y += 7 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_A])
		camera->center.x -= 7 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_S])
		camera->center.y -= 7 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_D])
		camera->center.x += 7 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_F])
		camera->fov += 7 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_G])
		camera->fov -= 7 * seconds_elapsed;
	//en caso que cambiemos el width y e height de la ventana hacemos la relaci�n para que no quede deforme.
	camera->aspect = window_width / window_height;

	//if we modify the camera fields, then update matrices
	camera->updateViewMatrix();
	camera->updateProjectionMatrix();
}

//keyboard press event 
void Application::onKeyDown( SDL_KeyboardEvent event )
{
	//to see all the keycodes: https://wiki.libsdl.org/SDL_Keycode
	switch (event.keysym.scancode)
	{
		case SDL_SCANCODE_ESCAPE: exit(0); break; //ESC key, kill the app
		case SDL_SCANCODE_1:
			render_mode = 1;
			break;
		case SDL_SCANCODE_2:
			render_mode = 2;
			break;

	}
}

//keyboard released event 
void Application::onKeyUp(SDL_KeyboardEvent event)
{
	//to see all the keycodes: https://wiki.libsdl.org/SDL_Keycode
	switch (event.keysym.scancode)
	{
	}
}

//mouse button event
void Application::onMouseButtonDown( SDL_MouseButtonEvent event )
{
	if (event.button == SDL_BUTTON_LEFT) //left mouse pressed
	{
	}
}

void Application::onMouseButtonUp( SDL_MouseButtonEvent event )
{
	if (event.button == SDL_BUTTON_LEFT) //left mouse unpressed
	{

	}
}

//when the app starts
void Application::start()
{
	std::cout << "launching loop..." << std::endl;
	launchLoop(this);
}
