Rubén Vera->241456->ruben.vera01@estudiant.upf.edu
Eneko Treviño->241679->eneko.trevino01@estudiant.upf.edu

Para usar nuestra aplicación hay que hacer lo siguiente, una vez ejecutado el codigo:
Presionar tecla 1-> Sin texturas ni colores, solo los triangulos
Presionar tecla 2-> Texturas puestas
Persionar flechas izquierda y derecha-> Movemos el ojo de la camara
Presionar W/A/S/D-> Movemos el centro de la camara
Presionar F-> Aumentamos el fov de la camara
Presionar G-> Disminuimos el fov de la camara