//this var comes from the vertex shader
//they are baricentric interpolated by pixel according to the distance to every vertex
varying vec3 v_wPos;
varying vec3 v_wNormal;
varying vec2 uv;	

//here create uniforms for all the data we need here
uniform sampler2D color_texture;
uniform vec3 ambient_light;
uniform vec3 diffuse_light;
uniform vec3 specular_light;
uniform vec3 ambient_reflection;
uniform vec3 diffuse_reflection;
uniform vec3 specular_reflection;
uniform float shininess;
uniform vec3 light_position;
uniform vec3 eye_of_camera;

void main()
{
	//here we set up the normal as a color to see them as a debug
	vec3 color = v_wNormal;
	vec4 texture = texture2D(color_texture, uv);

	vec3 t = texture.xyz;
	vec3 ka = t*ambient_reflection;
	vec3 kd = t*diffuse_reflection;
	vec3 ks = t*specular_reflection;

	//here write the computations for PHONG.
	vec3 la = ka*ambient_light;

	vec3 light_vector = light_position-v_wPos;
	light_vector = normalize(light_vector);

	float light_normal = dot(light_vector, v_wNormal);
	light_normal = clamp(light_normal, 0.0, 1.0);

	vec3 ld = kd*light_normal*diffuse_light;
		
	vec3 reflected = reflect(light_vector, v_wNormal);
	reflected = normalize(reflected);

	vec3 eye_vector = v_wPos-eye_of_camera;
	eye_vector = normalize(eye_vector);
	
	float reflected_eye = dot(reflected, eye_vector);
	reflected_eye = clamp(reflected_eye, 0.0, 1.0);
	
	float powering = pow(reflected_eye, 13);

	vec3 ls = ks*powering*specular_light;

	vec3 li = la+ld+ls;

	//set the ouput color por the pixel
	gl_FragColor = vec4( li, 1.0 ) * 1.0;
}
