#include "application.h"
#include "utils.h"
#include "image.h"
#include "camera.h"
#include "mesh.h"
#include "shader.h"
#include "texture.h"
#include "light.h"
#include "material.h"

Camera* camera = NULL;
Mesh* mesh = NULL;
Matrix44 model_matrix;
Shader* shader = NULL;
Shader* task1 = NULL;
Shader* task2 = NULL;
Shader* task3 = NULL;
Texture* texture = NULL;
Texture* normal_texture = NULL;
Light* light = NULL;
Material* material = NULL;
Vector3 ambient_light(0.3, 0.3, 0.3); //here we can store the global ambient light of the scene
int n_objects = 3;


Application::Application(const char* caption, int width, int height)
{
	this->window = createWindow(caption, width, height);

	// initialize attributes
	// Warning: DO NOT CREATE STUFF HERE, USE THE INIT 
	// things create here cannot access opengl
	int w,h;
	SDL_GetWindowSize(window,&w,&h);

	this->window_width = w;
	this->window_height = h;
	this->keystate = SDL_GetKeyboardState(NULL);
}

//Here we have already GL working, so we can create meshes and textures
void Application::init(void)
{
	std::cout << "initiating app..." << std::endl;
	
	//here we create a global camera and set a position and projection properties
	camera = new Camera();
	camera->lookAt(Vector3(0,20,20),Vector3(0,10,0),Vector3(0,1,0));
	camera->setPerspective(60,window_width / window_height,0.1,10000);

	//then we load a mesh
	mesh = new Mesh();
	mesh->loadOBJ("../res/meshes/lee.obj");

	//load the texture
	texture = new Texture();
	if(!texture->load("../res/textures/lee_color_specular.tga"))
	{
		std::cout << "Texture not found" << std::endl;
		exit(1);
	}
	normal_texture = new Texture();
	if (!normal_texture->load("../res/textures/lee_normal.tga"))
	{
		std::cout << "Texture not found" << std::endl;
		exit(1);
	}

	//we load the shaders
	shader = Shader::Get("../res/shaders/texture.vs","../res/shaders/texture.fs");
	task1 = Shader::Get("../res/shaders/task1.vs", "../res/shaders/task1.fs");
	task2 = Shader::Get("../res/shaders/task2.vs", "../res/shaders/task2.fs");
	task3 = Shader::Get("../res/shaders/task3.vs", "../res/shaders/task3.fs");


	//load whatever you need here
	light = new Light();
	//Creamos los 3 materiales
	//El primer material haremos el default
	objects[0].mate = new Material();
	//Al segundo material le adjudicaremos el color azul
	objects[1].mate = new Material();
	objects[1].mate->ambient = Vector3(0, 0, 1);
	objects[1].mate->diffuse = Vector3(0, 0, 1);
	objects[1].mate->specular = Vector3(0, 0, 1);
	//Al tercer material le adjudicamos el color rojo.
	objects[2].mate = new Material();
	objects[2].mate->ambient = Vector3(1, 0, 0);
	objects[2].mate->diffuse = Vector3(1, 0, 0);
	objects[2].mate->specular = Vector3(1, 0, 0);

}

//render one frame
void Application::render(void)
{
	// Clear the window and the depth buffer
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glEnable( GL_DEPTH_TEST );


	//Get the viewprojection
	camera->aspect = window_width / window_height;
	Matrix44 viewprojection = camera->getViewProjectionMatrix();
	
	//enable the shader

	shader->enable();
	for (int i = 0; i < n_objects; i++) {
		shader->setTexture("color_texture", texture, 0); //set texture in slot 0
		shader->setTexture("normal_texture", normal_texture, 1); //set texture in slot 1
		//Pasamos todo lo necesario para las uniforms del shader.
		shader->setVector3("diffuse_light", light->diffuse_color);
		shader->setVector3("specular_light", light->specular_color);
		shader->setVector3("light_position", light->position);
		shader->setVector3("ambient_light", ambient_light);
		shader->setVector3("eye_of_camera", camera->eye);
		//En este caso pasamos la informaci�n del material del objeto correspondiente
		shader->setVector3("ambient_reflection", objects[i].mate->ambient);
		shader->setVector3("diffuse_reflection", objects[i].mate->diffuse);
		shader->setVector3("specular_reflection", objects[i].mate->specular);
		shader->setFloat("shininess", objects[i].mate->shininess);
		//Modificamos la matriz model de los objetos correspondientes
		objects[i].model.setIdentity();
		objects[i].model.translate(0 + 15 * i, 0, 0 - 10 * i); //example of translation
		objects[i].model.rotate(0, Vector3(0, 1, 0));
		shader->setMatrix44("model", objects[i].model); //upload the transform matrix to the shader
		shader->setMatrix44("viewprojection", viewprojection); //upload viewprojection info to the shader
		//do the draw call into the GPU
		mesh->render(GL_TRIANGLES);
	}

	//disable shader
	shader->disable();

	//swap between front buffer and back buffer
	SDL_GL_SwapWindow(this->window);
}

//called after render
void Application::update(double seconds_elapsed)
{
	if (keystate[SDL_SCANCODE_SPACE])
	{
		model_matrix.rotateLocal(seconds_elapsed,Vector3(0,1,0));
	}

	//Movem l'ull de la camara pels eixos x i y en funci� del temps pressionant les fltexes.
	if (keystate[SDL_SCANCODE_RIGHT])
		camera->eye = camera->eye + Vector3(1, 0, 0) * seconds_elapsed * 15.0;
	else if (keystate[SDL_SCANCODE_LEFT])
		camera->eye = camera->eye + Vector3(-1, 0, 0) * seconds_elapsed * 15.0;
	if (keystate[SDL_SCANCODE_UP])
		camera->eye = camera->eye + Vector3(0, 1, 0) * seconds_elapsed * 15.0;
	else if (keystate[SDL_SCANCODE_DOWN])
		camera->eye = camera->eye + Vector3(0, -1, 0) * seconds_elapsed * 15.0;

	//Orbitem al voltant del mesh en els eixos x i y en funci� del temps pressionant les tecles corresponents.
	if (keystate[SDL_SCANCODE_O]) {
		Matrix44 R;
		R.setRotation(3 * seconds_elapsed, Vector3(1, 0, 0.1));//Apliquem una rotaci� a la matriu identitat de l'eix corresponent i l'angle anira augmentant en funci� del temps pressionat
		Vector3 new_front = R * (camera->eye - camera->center);//Calculem el vector front, per tenir l'angle que ens interessa a l'hora de posar l'ull de la camera on volem
		camera->eye = (camera->center + new_front);//Posem el ull de la camera on toca.
		camera->updateViewMatrix();
	}
	else if (keystate[SDL_SCANCODE_P]) {
		Matrix44 R;
		R.setRotation(3 * seconds_elapsed, Vector3(-1, 0, 0.1));
		Vector3 new_front = R * (camera->eye - camera->center);
		camera->eye = (camera->center + new_front);
		camera->updateViewMatrix();
	}
	if (keystate[SDL_SCANCODE_K]) {
		Matrix44 R;
		R.setRotation(3 * seconds_elapsed, Vector3(0, 1, 0));
		Vector3 new_front = R * (camera->eye - camera->center);
		camera->eye = (camera->center + new_front);
		camera->updateViewMatrix();
	}
	else if (keystate[SDL_SCANCODE_L]) {
		Matrix44 R;
		R.setRotation(3 * seconds_elapsed, Vector3(0, -1, 0));
		Vector3 new_front = R * (camera->eye - camera->center);
		camera->eye = (camera->center + new_front);
		camera->updateViewMatrix();
	}

	//Movem el centre de la camera en funci� del temps pressionant les tecles corresponents
	if (keystate[SDL_SCANCODE_W])
		camera->center.y += 15 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_A])
		camera->center.x -= 15 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_S])
		camera->center.y -= 15 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_D])
		camera->center.x += 15 * seconds_elapsed;

	//Augmentem o disminuim el fov en funci� del temps pressionant les tecles corresponents
	if (keystate[SDL_SCANCODE_F])
		camera->fov += 16 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_G])
		camera->fov -= 16 * seconds_elapsed;

	if (keystate[SDL_SCANCODE_1])
		shader = task1;
	if (keystate[SDL_SCANCODE_2])
		shader = task2;
	if (keystate[SDL_SCANCODE_3])
		shader = task3;
}

//keyboard press event 
void Application::onKeyPressed( SDL_KeyboardEvent event )
{
	//to see all the keycodes: https://wiki.libsdl.org/SDL_Keycode
	switch (event.keysym.scancode){
		case SDL_SCANCODE_R: Shader::ReloadAll(); break;
        case SDL_SCANCODE_ESCAPE: exit(0); break; //ESC key, kill the app


	}

}

//mouse button event
void Application::onMouseButtonDown( SDL_MouseButtonEvent event )
{
	if (event.button == SDL_BUTTON_LEFT) //left mouse pressed
	{

	}
}

void Application::onMouseButtonUp( SDL_MouseButtonEvent event )
{
	if (event.button == SDL_BUTTON_LEFT) //left mouse unpressed
	{

	}
}

//when the app starts
void Application::start()
{
	std::cout << "launching loop..." << std::endl;
	launchLoop(this);
}
