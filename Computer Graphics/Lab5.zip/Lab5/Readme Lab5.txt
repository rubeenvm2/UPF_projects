Rubén Vera -> 241456->ruben.vera01@estudiant.upf.edu
Eneko Treviño->241679->eneko.trevino@estudiant.upf.edu

Para usar nuestra aplicación hay que utilizar las siguientes teclas una vez ejecutada el código:

Tecla->O: Orbita la cámara alrededor del eje y, en sentido ascendente
Tecla->P: Orbita la cámara al contrario que O, es decir, orbita la camara en sentido descendente.
Tecla->K: Orbita la cámara en sentido de la X, hacia la derecha
Tecla->L: Orbita la cámara en sentido negativo de las X, hacia la izquierda
Tecla->W/A/S/D: Movemos el centro de la cámara en los sentidos de logica de las teclas W/A/S/D.
Tecla->F: Aumentamos el campo de visión de la cámara.
Tecla->G: Disminuimos el campo de visión de la cámara

Tecla->1: Aplicamos la primera tarea(aplicar textura a la iluminación)
Tecla->2: Aplicamos la segunda tarea(specular)
Tecla->3: Aplicamos la tercera tarea(normal_map)

Para la parte extra del lab 3, una vez ejecutado el codigo:

Tecla->2: Visualización de la parte del lab 5


