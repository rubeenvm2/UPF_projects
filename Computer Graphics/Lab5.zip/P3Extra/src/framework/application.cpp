#include "application.h"
#include "utils.h"
#include "image.h"
#include "mesh.h"
#include "light.h"
#include "material.h"

Light* light = NULL;
Material* material = NULL;

Vector3 ambient_light(0.3, 0.3, 0.3);
Application::Application(const char* caption, int width, int height)
{
	this->window = createWindow(caption, width, height);

	// initialize attributes
	// Warning: DO NOT CREATE STUFF HERE, USE THE INIT 
	// things create here cannot access opengl
	int w,h;
	SDL_GetWindowSize(window,&w,&h);

	this->window_width = w;
	this->window_height = h;
	this->keystate = SDL_GetKeyboardState(NULL);

	zbuffer.resize(w, h);
	framebuffer.resize(w, h);
}

//Here we have already GL working, so we can create meshes and textures
//Here we have already GL working, so we can create meshes and textures
void Application::init(void)
{
	std::cout << "initiating app..." << std::endl;
	
	//here we create a global camera and set a position and projection properties
	camera = new Camera();
	camera->lookAt(Vector3(0,10,20),Vector3(0,10,0),Vector3(0,1,0)); //define eye,center,up
	camera->perspective(60, window_width / (float)window_height, 0.1, 10000); //define fov,aspect,near,far

	//load a mesh
	mesh = new Mesh();
	if( !mesh->loadOBJ("lee.obj") )
		std::cout << "FILE Lee.obj NOT FOUND" << std::endl;

	//load the texture
	texture = new Image();
	texture->loadTGA("color.tga");

	texture_normal = new Image();
	texture_normal->loadTGA("lee_normal.tga");
	//Inicializamos el zbuffer poniendo los valores de todos los pixeles a un valor muy alto.
	for( int i = 0; i < window_width; i++) {
		for (int j = 0; j < window_height; j++) {
			zbuffer.setPixel(i, j, 10000000000000);
		}
	}
	light = new Light();
	material = new Material();
}

//this function fills the triangle by computing the bounding box of the triangle in screen space and using the barycentric interpolation
//to check which pixels are inside the triangle. It is slow for big triangles, but faster for small triangles 
void Application::fillTriangle(const Vector3& p0, const Vector3& p1, const Vector3& p2, const Vector2& uv0, const Vector2& uv1, const Vector2& uv2, const Vector3& n0, const Vector3& n1, const Vector3& n2, const Vector3& ver0, const Vector3& ver1, const Vector3& ver2)
{
	
	//compute triangle bounding box in screen space
	Vector3 min;
	Vector3 max;
	for (int i = 0; i < 3; i++) {
		if (p0.v[i] <= p1.v[i] && p0.v[i] <= p2.v[i]) {
			min.v[i] = p0.v[i];
			if (p1.v[i] < p2.v[i]) {
				max.v[i] = p2.v[i];
			}
			else {
				max.v[i] = p1.v[i];
			}
		}
		else if(p1.v[i] < p0.v[i] && p1.v[i] <= p2.v[i]) {
			min.v[i] = p1.v[i];
			if (p0.v[i] < p2.v[i]) {
				max.v[i] = p2.v[i];
			}
			else {
				max.v[i] = p0.v[i];
			}
		}
		else if (p2.v[i] < p0.v[i] && p2.v[i] < p1.v[i]) {
			min.v[i] = p2.v[i];
			if (p0.v[i] < p1.v[i]) {
				max.v[i] = p1.v[i];
			}
			else {
				max.v[i] = p0.v[i];
			}
		}
	}

	//clamp to screen area
	min.x = clamp(min.x, 0, window_width - 1);
	min.y = clamp(min.y, 0, window_height - 1);
	min.z = clamp(min.z, -1, 1);	
	max.x = clamp(max.x, 0, window_width - 1);
	max.y = clamp(max.y, 0, window_height - 1);
	max.z = clamp(max.z, -1, 1);

	Vector3 v0 = p1 - p0;
	Vector3 v1 = p2 - p0;
	Vector3 v2;
	float d00 = v0.dot(v0);
	float d01 = v0.dot(v1);
	float d11 = v1.dot(v1);


	//Como se hizo en la practica 3, vamos desde la minima x e y de la bounding box hasta sus maximos y calculamos los coeficientes u,v,w de cada pixel de la bounding box.
	for (int i = min.x; i < max.x; i++) {
		for (int j = min.y; j < max.y; j++) {
			v2.x = i - p0.x;
			v2.y = j - p0.y;
			float d20 = v2.dot(v0);
			float d21 = v2.dot(v1);
			float denom = d00 * d11 - d01 * d01;
			float v = (d11 * d20 - d01 * d21) / denom;
			float w = (d00 * d21 - d01 * d20) / denom;
			float u = 1.0 - v - w;
			if (u < 0 || u > 1 || v < 0 || v > 1 || w < 0 || w > 1) {
				continue;
			}

			//Hacemos la interpolaci�n de los valores z para cada pixel segun sus coeficientes u,v,w.
			float z = p0.z * u + p1.z * v + p2.z * w;
			//Hacemos la interpolaci�n de las coordenadas de textura para cada pixel segun sus coeficientes u,v,w.
			Vector2 texture_coords = uv0 * u + uv1 * v + uv2 * w;

			int tex_x = texture_coords.x * (texture->width - 1);
			int tex_y = texture_coords.y * (texture->height - 1);

			int texture_normal_x = texture_coords.x * (texture_normal->width -1 );
			int texture_normal_y = texture_coords.y * (texture_normal->height - 1);
			//Cogemos el Color de la textura en el pixel en coordenadas de textura
			Color text = texture->getPixel(tex_x, tex_y);

			//Color normal_color = texture_normal->getPixelSafe(texture_coords.x, texture_coords.y);
			Color normal_color = texture_normal->getPixel(texture_normal_x, texture_normal_y);
			
			//Calculamos la interpolacion de los vertices de los vectores en coords mundo para saber la posicion del punto i,j en coords mundo.
			Vector3 position = ver0 * u + ver1 * v + ver2 * w;

			Vector3 textures = Vector3(text.r, text.g, text.b)/255.0;
			
			Vector3 normal_pos = Vector3(normal_color.r, normal_color.g, normal_color.b)/255.0;
			normal_pos = Vector3(normal_pos.x * 2.0 - 1.0, normal_pos.y *  2.0 -  1.0, normal_pos.z *  2.0 -  1.0);
			normal_pos.normalize();

			Vector3 ka = Vector3(textures.x * material->ambient.x, textures.y * material->ambient.y, textures.z * material->ambient.z);
			Vector3 kd = Vector3(textures.x * material->diffuse.x, textures.y * material->diffuse.y, textures.z * material->diffuse.z);
			Vector3 ks = Vector3(textures.x * material->specular.x, textures.y * material->specular.y, textures.z * material->specular.z);
			
			//Calculamos el vector la
			Vector3 la;
			la.x = ka.x * ambient_light.x;
			la.y = ka.y * ambient_light.y;
			la.z = ka.z * ambient_light.z;
			
			//Calculamos el vector L y lo normalizamos
			Vector3 light_vector = light->position - position;
			light_vector = light_vector.normalize();

			//Calculamos el producto escalar de L y N y lo clampeamos para que su valor oscile entre 0 y 1
			float light_normal = light_vector.dot(normal_pos);
			light_normal = clamp(light_normal, 0.0, 1.0);

			//Calculamos el vector ld.
			Vector3 ld;
			ld.x = kd.x * light_normal * light->diffuse_color.x;
			ld.y = kd.y * light_normal * light->diffuse_color.y;
			ld.z = kd.z * light_normal * light->diffuse_color.z;

			//Calculamos el vector R haciendo uso de la formula de reflexion.
			Vector3 reflected = normal_pos*2.f*normal_pos.dot(light_vector) - light_vector;
			reflected = reflected.normalize();

			//Calculamos el vector V
			Vector3 eye_vector = camera->eye - position;
			eye_vector = eye_vector.normalize();

			//Calculamos el producto escalar entre R y V y lo clampeamos para que su valor oscile entre 0 y 1.
			float reflected_eye = reflected.dot(eye_vector);
			reflected_eye = clamp(reflected_eye, 0.0, 1.0);

			//Calculamos el vector ls
			Vector3 ls;
			ls.x = ks.x * pow(reflected_eye, material->shininess) * light->specular_color.x;
			ls.y = ks.x * pow(reflected_eye, material->shininess) * light->specular_color.y;
			ls.z = ks.x * pow(reflected_eye, material->shininess) * light->specular_color.z;

			//Calculamos el vector li y clampeamos su x, y y z para que sus valores oscilen entre 0 y 1 y haga el calculo del color adecuadamente.
			Vector3 li = la + ld + ls;

			li.x = clamp(li.x, 0.0, 1.0);
			li.y = clamp(li.y, 0.0, 1.0);
			li.z = clamp(li.z, 0.0, 1.0);
			//Calculamos el color adecuado multiplicando por 255 ya que los colores en este caso son [0,...,255] y no [0,...,1] como en el lab 4
			Color lab4 = Color(li.x*255, li.y*255, li.z*255);
			if (z < zbuffer.getPixel(i,j)) {
				//Pintamos el pixel del valor adecuado.
				framebuffer.setPixel(i, j, lab4);
				//Actualizamos el zbuffer.
				zbuffer.setPixel(i, j, z);
			}

		}
	}

}

//render one frame
void Application::render(Image& framebuffer)
{
	framebuffer.fill(Color(40, 45, 60)); //clear
	zbuffer.fill(100000000);

	//for every point of the mesh (to draw triangles take three points each time and connect the points between them (1,2,3,   4,5,6,   ...)
	for (int i = 0; i < mesh->vertices.size(); i = i+3)
	{
		Vector3 vertex0 = mesh->vertices[i]; //extract vertex from mesh
		Vector3 vertex1 = mesh->vertices[i+1]; //extract vertex from mesh
		Vector3 vertex2 = mesh->vertices[i+2]; //extract vertex from mesh
		Vector2 texcoord0 = mesh->uvs[i]; 
		Vector2 texcoord1 = mesh->uvs[i+1]; 
		Vector2 texcoord2 = mesh->uvs[i+2]; //texture coordinate of the vertex (they are normalized, from 0,0 to 1,1)
		Vector3 normals0 = mesh->normals[i];
		Vector3 normals1 = mesh->normals[i + 1];
		Vector3 normals2 = mesh->normals[i + 2];
		//Pasamos las coordenadas de textura de 0,1 a la width y la height de las texturas.
		/*texcoord0.x = (texcoord0.x) * texture->width;
		texcoord0.y = (texcoord0.y) * texture->height;
		texcoord1.x = (texcoord1.x) * texture->width;
		texcoord1.y = (texcoord1.y) * texture->height;
		texcoord2.x = (texcoord2.x) * texture->width;
		texcoord2.y = (texcoord2.y) * texture->height;*/

		//project every point in the mesh to normalized coordinates using the viewprojection_matrix inside camera
		Vector3 normalized_point0 = camera->projectVector(vertex0);
		Vector3 normalized_point1 = camera->projectVector(vertex1);
		Vector3 normalized_point2 = camera->projectVector(vertex2);
		


		//convert from normalized (-1 to +1) to framebuffer coordinates (0,W)
		normalized_point0.x = (normalized_point0.x + 1) * window_width / 2;
		normalized_point0.y = (normalized_point0.y + 1) * window_height / 2;
		normalized_point1.x = (normalized_point1.x + 1) * window_width / 2;
		normalized_point1.y = (normalized_point1.y + 1) * window_height / 2;
		normalized_point2.x = (normalized_point2.x + 1) * window_width / 2;
		normalized_point2.y = (normalized_point2.y + 1) * window_height / 2;


		//paint points in framebuffer (using your drawTriangle function or the fillTriangle function)
		switch (render_mode)
		{
		case 1:
			framebuffer.Triangle(normalized_point0.x, normalized_point0.y, normalized_point1.x, normalized_point1.y, normalized_point2.x, normalized_point2.y, Color::WHITE);
			break;
		case 2:
			fillTriangle(normalized_point0, normalized_point1, normalized_point2, texcoord0, texcoord1, texcoord2, normals0, normals1, normals2, vertex0, vertex1, vertex2);
			break;
		}
	}
}

//called after render
void Application::update(double seconds_elapsed)
{

	if (keystate[SDL_SCANCODE_LEFT])
		camera->eye.x -= 7 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_RIGHT])
		camera->eye.x += 7 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_W])
		camera->center.y += 7 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_A])
		camera->center.x -= 7 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_S])
		camera->center.y -= 7 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_D])
		camera->center.x += 7 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_F])
		camera->fov += 7 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_G])
		camera->fov -= 7 * seconds_elapsed;
	//en caso que cambiemos el width y e height de la ventana hacemos la relaci�n para que no quede deforme.
	camera->aspect = window_width / window_height;

	//if we modify the camera fields, then update matrices
	camera->updateViewMatrix();
	camera->updateProjectionMatrix();
}

//keyboard press event 
void Application::onKeyDown( SDL_KeyboardEvent event )
{
	//to see all the keycodes: https://wiki.libsdl.org/SDL_Keycode
	switch (event.keysym.scancode)
	{
		case SDL_SCANCODE_ESCAPE: exit(0); break; //ESC key, kill the app
		case SDL_SCANCODE_1:
			render_mode = 1;
			break;
		case SDL_SCANCODE_2:
			render_mode = 2;
			break;

	}
}

//keyboard released event 
void Application::onKeyUp(SDL_KeyboardEvent event)
{
	//to see all the keycodes: https://wiki.libsdl.org/SDL_Keycode
	switch (event.keysym.scancode)
	{
	}
}

//mouse button event
void Application::onMouseButtonDown( SDL_MouseButtonEvent event )
{
	if (event.button == SDL_BUTTON_LEFT) //left mouse pressed
	{
	}
}

void Application::onMouseButtonUp( SDL_MouseButtonEvent event )
{
	if (event.button == SDL_BUTTON_LEFT) //left mouse unpressed
	{

	}
}

//when the app starts
void Application::start()
{
	std::cout << "launching loop..." << std::endl;
	launchLoop(this);
}
