# Information

Put resource files in this folder like images, shaders, etc.
