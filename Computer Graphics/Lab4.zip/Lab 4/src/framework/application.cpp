#include "application.h"
#include "utils.h"
#include "includes.h"
#include "utils.h"

#include "image.h"
#include "mesh.h"
#include "shader.h"
#include "texture.h"
#include "camera.h"
#include "material.h"
#include "light.h"

Camera* camera = NULL;
Mesh* mesh = NULL;
Shader* shader = NULL;
int n_lights = 3;
int n_meshes = 1;
Material* material = NULL;
Light* light[3] = { NULL,NULL,NULL };
Shader* phong_shader = NULL;
Shader* gouraud_shader = NULL;

Vector3 ambient_light(0.1,0.2,0.3); //here we can store the global ambient light of the scene

float angle = 0;

Application::Application(const char* caption, int width, int height)
{
	this->window = createWindow(caption, width, height);

	// initialize attributes
	// Warning: DO NOT CREATE STUFF HERE, USE THE INIT 
	// things create here cannot access opengl
	int w,h;
	SDL_GetWindowSize(window,&w,&h);

	this->window_width = w;
	this->window_height = h;
	this->keystate = SDL_GetKeyboardState(NULL);
}

//Here we have already GL working, so we can create meshes and textures
void Application::init(void)
{
	std::cout << "initiating app..." << std::endl;
	
	//here we create a global camera and set a position and projection properties
	camera = new Camera();
	camera->lookAt(Vector3(0,20,20),Vector3(0,10,0),Vector3(0,1,0));
	camera->setPerspective(60,window_width / window_height,0.1,10000);

	//then we load a mesh
	mesh = new Mesh();
	if( !mesh->loadOBJ( "../res/meshes/lee.obj" ) )
		std::cout << "FILE Lee.obj NOT FOUND " << std::endl;

	//we load one or several shaders...
	shader = Shader::Get( "../res/shaders/simple.vs", "../res/shaders/simple.fs" );

	//load your Gouraud and Phong shaders here and stored them in some global variables

	gouraud_shader = Shader::Get("../res/shaders/gouraud.vs", "../res/shaders/gouraud.fs");
	phong_shader = Shader::Get("../res/shaders/phong.vs", "../res/shaders/phong.fs");

	//create 3 lights and some materials
	light[0] = new Light();

	light[1] = new Light();	
	light[1]->diffuse_color = Vector3(0.2f,0.2f,0.2f);
	light[1]->position = Vector3(20, 20, 0);
	light[1]->specular_color = Vector3(0.2f, 0.2f, 0.2f);

	light[2] = new Light();
	light[2]->diffuse_color = Vector3(0.8f, 0.8f, 0.8f);
	light[2]->position = Vector3(100, 100, 0);
	light[2]->specular_color = Vector3(0.8f, 0.8f, 0.8f);

	material = new Material();
	
}

//render one frame
void Application::render(void)
{
	//update the aspect of the camera acording to the window size
	camera->aspect = window_width / window_height;
	camera->updateProjectionMatrix();
	//Get the viewprojection matrix from our camera
	Matrix44 viewprojection = camera->getViewProjectionMatrix();

	//set the clear color of the colorbuffer as the ambient light so it matches
	glClearColor(ambient_light.x, ambient_light.y, ambient_light.z, 1.0);

	// Clear the window and the depth buffer
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); //clear framebuffer and depth buffer 
	glEnable( GL_DEPTH_TEST ); //enable depth testing for occlusions
	glDepthFunc(GL_LEQUAL); //Z will pass if the Z is LESS or EQUAL to the Z of the pixel
	glDisable(GL_BLEND); // Deshabilitem el blend.
	//choose a shader and enable it
	shader->enable();
	//pass all the info needed by the shader to do the computations
	//send the material and light uniforms to the shader
	shader->setVector3("ambient_light", ambient_light);
	//Ho fem per les 3 llums deixant la llum d'ambient constant i fent el sumatori de la resta
	for (int i = 0; i < n_lights; i++) {
		shader->setVector3("ambient_reflection", material->ambient);
		shader->setVector3("diffuse_reflection", material->diffuse);
		shader->setVector3("specular_reflection", material->specular);
		shader->setVector3("diffuse_light", light[i]->diffuse_color);
		shader->setVector3("specular_light", light[i]->specular_color);
		shader->setVector3("light_position", light[i]->position);
		shader->setVector3("eye_of_camera", camera->eye);
		shader->setFloat("shininess", material->shininess);
		//Creem diverses meshes
		for (int j = 0; j < n_meshes; j++) {
			Matrix44 model_matrix;
			model_matrix.setIdentity();
			model_matrix.translate(0+15*j, 0, 0-10*j); //example of translation
			model_matrix.rotate(angle, Vector3(0, 1, 0));
			shader->setMatrix44("model", model_matrix); //upload the transform matrix to the shader
			shader->setMatrix44("viewprojection", viewprojection); //upload viewprojection info to the shader
			//do the draw call into the GPU
			mesh->render(GL_TRIANGLES);
		}
		shader->setVector3("ambient_light", Vector3(0,0,0));//Per la resta de calculs posem l'ambient light a 0 per tal de no sumar-lo.
		glEnable(GL_BLEND); // Habilitem el Blend
		glBlendFunc(GL_ONE, GL_ONE); //Posme el blend en el mode adequat.
		
	}

	//disable shader when we do not need it any more
	shader->disable();

	//swap between front buffer and back buffer
	SDL_GL_SwapWindow(this->window);
}

//called after render
void Application::update(double seconds_elapsed)
{
	//Augmentem l'angle en funci� del temps pressionant l'espai
	if (keystate[SDL_SCANCODE_SPACE])
		angle += seconds_elapsed;
	//Movem l'ull de la camara pels eixos x i y en funci� del temps pressionant les fltexes.
	if (keystate[SDL_SCANCODE_RIGHT])
		camera->eye = camera->eye + Vector3(1, 0, 0) * seconds_elapsed * 15.0;
	else if (keystate[SDL_SCANCODE_LEFT])
		camera->eye = camera->eye + Vector3(-1, 0, 0) * seconds_elapsed * 15.0;
	if (keystate[SDL_SCANCODE_UP])
		camera->eye = camera->eye + Vector3(0, 1, 0) * seconds_elapsed * 15.0;
	else if (keystate[SDL_SCANCODE_DOWN])
		camera->eye = camera->eye + Vector3(0, -1, 0) * seconds_elapsed * 15.0;
	//Orbitem al voltant del mesh en els eixos x i y en funci� del temps pressionant les tecles corresponents.
	if (keystate[SDL_SCANCODE_O]) {
		Matrix44 R;
		R.setRotation(3 * seconds_elapsed, Vector3(1,0,0.1));//Apliquem una rotaci� a la matriu identitat de l'eix corresponent i l'angle anira augmentant en funci� del temps pressionat
		Vector3 new_front = R * (camera->eye - camera->center);//Calculem el vector front, per tenir l'angle que ens interessa a l'hora de posar l'ull de la camera on volem
		camera->eye = (camera->center + new_front);//Posem el ull de la camera on toca.
		camera->updateViewMatrix();
	}
	else if (keystate[SDL_SCANCODE_P]) {
		Matrix44 R;
		R.setRotation(3 * seconds_elapsed, Vector3(-1, 0, 0.1));
		Vector3 new_front = R * (camera->eye - camera->center);
		camera->eye = (camera->center + new_front);
		camera->updateViewMatrix();
	}
	if (keystate[SDL_SCANCODE_K]) {
		Matrix44 R;
		R.setRotation(3 * seconds_elapsed, Vector3(0, 1, 0));
		Vector3 new_front = R * (camera->eye - camera->center);
		camera->eye = (camera->center + new_front);
		camera->updateViewMatrix();
	}
	else if (keystate[SDL_SCANCODE_L]) {
		Matrix44 R;
		R.setRotation(3 * seconds_elapsed, Vector3(0, -1, 0));
		Vector3 new_front = R * (camera->eye - camera->center);
		camera->eye = (camera->center + new_front);
		camera->updateViewMatrix();
	}
	//Movem el centre de la camera en funci� del temps pressionant les tecles corresponents
	if (keystate[SDL_SCANCODE_W])
		camera->center.y += 15 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_A])
		camera->center.x -= 15 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_S])
		camera->center.y -= 15 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_D])
		camera->center.x += 15 * seconds_elapsed;
	//Augmentem o disminuim el fov en funci� del temps pressionant les tecles corresponents
	if (keystate[SDL_SCANCODE_F])
		camera->fov += 16 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_G])
		camera->fov -= 16 * seconds_elapsed;
	//Movem la posici� de les llums, segons la tecla podem moure qualsevol de les 3 llums
	if (keystate[SDL_SCANCODE_X])
		light[0]->position.x -= 50 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_Z])
		light[0]->position.x += 50 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_C])
		light[1]->position.x -= 50 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_V])
		light[1]->position.x += 50 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_B])
		light[2]->position.x -= 50 * seconds_elapsed;
	if (keystate[SDL_SCANCODE_N])
		light[2]->position.x += 50 * seconds_elapsed;
	//En funci� del que clickem aplicarem gouraud o phong.
	if (keystate[SDL_SCANCODE_1])
		shader = gouraud_shader;
	if (keystate[SDL_SCANCODE_2])
		shader = phong_shader;
}

//keyboard press event 
void Application::onKeyPressed( SDL_KeyboardEvent event )
{
	switch(event.keysym.sym)
	{
		case SDLK_ESCAPE: exit(0); break; //ESC key, kill the app
		case SDLK_r: 
			Shader::ReloadAll(); //Reload the view
			break; 
		case SDLK_KP_PLUS:
			n_meshes++;//Augmentem el numero de meshes per crear mes "caps"
			
	}
}

//mouse button event
void Application::onMouseButtonDown( SDL_MouseButtonEvent event )
{
	if (event.button == SDL_BUTTON_LEFT) //left mouse pressed
	{
	}

}

void Application::onMouseButtonUp( SDL_MouseButtonEvent event )
{
	if (event.button == SDL_BUTTON_LEFT) //left mouse unpressed
	{

	}
}

//when the app starts
void Application::start()
{
	std::cout << "launching loop..." << std::endl;
	launchLoop(this);
}
