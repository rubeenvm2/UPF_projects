Rubén Vera -> 241456->ruben.vera01@estudiant.upf.edu
Eneko Treviño->241679->eneko.trevino@estudiant.upf.edu

Para usar nuestra aplicación hay que utilizar las siguientes teclas una vez ejecutada el código:

Tecla->O: Orbita la cámara alrededor del eje y, en sentido ascendente
Tecla->P: Orbita la cámara al contrario que O, es decir, orbita la camara en sentido descendente.
Tecla->K: Orbita la cámara en sentido de la X, hacia la derecha
Tecla->L: Orbita la cámara en sentido negativo de las X, hacia la izquierda
Tecla->W/A/S/D: Movemos el centro de la cámara en los sentidos de logica de las teclas W/A/S/D.
Tecla->F: Aumentamos el campo de visión de la cámara.
Tecla->G: Disminuimos el campo de visión de la cámara
Tecla->X/Z: Posición de la luz [0], movemos su posición x, aumentandolo en X y disminuyendolo en Z
Tecla->C/V: Posición de la luz [1], movemos su posición x, aumentandolo en C y disminuyendolo en V
Tecla->B/N: Posición de la luz [2], movemos su posición x, aumentandolo en B y disminuyendolo en N
Tecla->1: Aplicamos el gouraud shader.
Tecla->2: Aplicamos el phong shader.
Tecla->+: Aumentamos el numero de meshes.


