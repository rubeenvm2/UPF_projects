#include "application.h"
#include "utils.h"
#include "image.h"

Application::Application(const char* caption, int width, int height)
{
	this->window = createWindow(caption, width, height);

	// initialize attributes
	// Warning: DO NOT CREATE STUFF HERE, USE THE INIT 
	// things create here cannot access opengl
	int w,h;
	SDL_GetWindowSize(window,&w,&h);

	this->window_width = w;
	this->window_height = h;
	this->keystate = SDL_GetKeyboardState(NULL);

	framebuffer.resize(w, h);
}

//Here we have already GL working, so we can create meshes and textures
void Application::init(void)
{
	std::cout << "initiating app..." << std::endl;

	//here add your init stuff
	table.resize(this->window_height);
	for (int i = 0; i < table.size(); i++) {
		table[i].minx = 100000;
		table[i].maxx = -100000;
	}
}

//render one frame
void Application::render( Image& framebuffer )
{
	//clear framebuffer if we want to start from scratch
	//here you can add your code to fill the framebuffer
	switch (render_mode) {
	case 0:
		framebuffer.fill(Color::BLACK);//Se ejecuta constantemente y lo limpia perma
		if (n_clicks == 2) {
			framebuffer.DDA(mouse.x, mouse.y, mouse2.x, mouse2.y, Color::WHITE);
		}
		break;
	case 1:
		framebuffer.fill(Color::BLACK);//Se ejecuta constantemente y lo limpia perma
		if (n_clicks == 2) {
			framebuffer.Bresenham(mouse.x, mouse.y, mouse2.x, mouse2.y, Color::WHITE);
		}
		break;
	case 2:
		framebuffer.fill(Color::BLACK);//Se ejecuta constantemente y lo limpia perma
		if (n_clicks == 2) {
			framebuffer.BresenhamCircle(mouse.x, mouse.y, distance(mouse, mouse2), Color::WHITE, FALSE);
		}
		break;
	case 3:
		framebuffer.fill(Color::BLACK);//Se ejecuta constantemente y lo limpia perma
		if (n_clicks == 3) {
			framebuffer.Triangle(mouse.x, mouse.y, mouse2.x, mouse2.y, mouse3.x, mouse3.y, Color::WHITE, TRUE, table);
		}
		break;
	case 4:
		framebuffer.fill(Color::BLACK);//Se ejecuta constantemente y lo limpia perma
		if (n_clicks == 3) {
			framebuffer.drawTriangleInterpolated(mouse.x, mouse.y, mouse2.x, mouse2.y, mouse3.x, mouse3.y, Color::RED, Color::GREEN, Color::BLUE, table);
		}
		break;
	case 5:
		framebuffer.fill(Color::BLACK);//Se ejecuta constantemente y lo limpia perma
		//framebuffer.Bresenham(50, 100, 180, 200, Color::WHITE);//1
		//framebuffer.Bresenham(50, 100, 180, 300, Color::WHITE);//2
		//framebuffer.Bresenham(180, 100, 50, 300, Color::WHITE);//3
		//framebuffer.Bresenham(180, 100, 50, 200, Color::WHITE);//4
		//framebuffer.Bresenham(180, 200, 50, 100, Color::WHITE);//5
		//framebuffer.Bresenham(180, 300, 50, 100, Color::WHITE);//6 
		//framebuffer.Bresenham(150, 150, 160, 100, Color::WHITE);//7
		//framebuffer.Bresenham(50, 200, 180, 100, Color::WHITE);//8
		break;
	}
}

//called after render
void Application::update(double seconds_elapsed)
{
	//to see all the keycodes: https://wiki.libsdl.org/SDL_Keycode
	if (keystate[SDL_SCANCODE_SPACE]) //if key space is pressed
	{
		//...
	}

	//to read mouse position use mouse_position
}

//keyboard press event 
void Application::onKeyDown( SDL_KeyboardEvent event )
{
	//to see all the keycodes: https://wiki.libsdl.org/SDL_Keycode
	switch (event.keysym.scancode)
	{
	case SDL_SCANCODE_ESCAPE:
		exit(0);
		break; //ESC key, kill the app
	case SDL_SCANCODE_0:
		render_mode = 0;
		n_clicks = 0;
		break;
	case SDL_SCANCODE_1:
		render_mode = 1;
		n_clicks = 0;

		break;
	case SDL_SCANCODE_2:
		render_mode = 2;
		n_clicks = 0;

		break;
	case SDL_SCANCODE_3:
		render_mode = 3;
		n_clicks = 0;

		break;
	case SDL_SCANCODE_4:
		render_mode = 4;
		n_clicks = 0;
		break;
	}
}

//keyboard key up event 
void Application::onKeyUp(SDL_KeyboardEvent event)
{
	//...
}

//mouse button event
void Application::onMouseButtonDown( SDL_MouseButtonEvent event )
{
	if (event.button == SDL_BUTTON_LEFT) //left mouse pressed
	{
		if (n_clicks == 0) {
			mouse = mouse_position;
			n_clicks++;
		}
		else if (n_clicks == 1) {
			mouse2 = mouse_position;
			n_clicks++;
		}
		else if (n_clicks == 2) {
			if (render_mode == 3 || render_mode == 4) {
				mouse3 = mouse_position;
				n_clicks++;
			}
			else {
				n_clicks = 0;
			}
		}
		else {
			n_clicks = 0;
		}

	}
}

void Application::onMouseButtonUp( SDL_MouseButtonEvent event )
{
	if (event.button == SDL_BUTTON_LEFT) //left mouse unpressed
	{
	}
}

//when the app starts
void Application::start()
{
	std::cout << "launching loop..." << std::endl;
	launchLoop(this);
}
