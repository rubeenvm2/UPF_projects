#include "application.h"
#include "utils.h"
#include "image.h"

Application::Application(const char* caption, int width, int height)
{
	this->window = createWindow(caption, width, height);

	// initialize attributes
	// Warning: DO NOT CREATE STUFF HERE, USE THE INIT 
	// things create here cannot access opengl
	int w,h;
	SDL_GetWindowSize(window,&w,&h);

	this->window_width = w;
	this->window_height = h;
	this->keystate = SDL_GetKeyboardState(NULL);

	framebuffer.resize(w, h);
}

//Here we have already GL working, so we can create meshes and textures
void Application::init(void)
{
	std::cout << "initiating app..." << std::endl;
	//here add your init stuff
	if (myimage->loadTGA("1.tga")==false) {
		std::cout << "error" << std::endl;
	}
	if (canvas->loadTGA("toolbar.tga") == false) {
		std::cout << "error" << std::endl;
	}
	if (myimage2->loadTGA("c.tga") == false) {
		std::cout << "error" << std::endl;
	}
	for (int i = 0; i < num_particulas; i++) {
		particulas[i].size = rand() % 15;
		particulas[i].x = (float) randomValue() * (window_width- particulas[i].size-1);
		particulas[i].y = (float) randomValue() * (window_height- particulas[i].size-1);
		particulas[i].speed = (rand() % 10)+1;

	}
}

//render one frame
void Application::render( Image& framebuffer )
{
	//clear framebuffer if we want to start from scratch
	framebuffer.fill(Color::BLACK);
	

	switch (render_mode) {
		case 1:
			//H
			framebuffer.drawRectangle(90, 200, 30, 200, Color::RED, TRUE);
			framebuffer.drawRectangle(210, 200, 30, 200, Color::RED, TRUE);
			framebuffer.drawRectangle(120, 285, 90, 25, Color::RED, FALSE);

			//E
			framebuffer.drawRectangle(255, 200, 25, 200, Color::PURPLE, TRUE);
			framebuffer.drawRectangle(280, 200, 65, 22, Color::PURPLE, FALSE);
			framebuffer.drawRectangle(280, 290, 65, 22, Color::PURPLE, FALSE);
			framebuffer.drawRectangle(280, 378, 65, 22, Color::PURPLE, FALSE);
			//L
			framebuffer.drawRectangle(365, 200, 25, 200, Color::YELLOW , TRUE);
			framebuffer.drawRectangle(390, 200, 70, 25, Color::YELLOW, FALSE);
			//L
			framebuffer.drawRectangle(477, 200, 25, 200, Color::YELLOW, TRUE);
			framebuffer.drawRectangle(502, 200, 70, 25, Color::YELLOW, FALSE);
			//O
			framebuffer.drawCircle(682, 300, 110, Color::GREEN , FALSE);
			//Lineas
			framebuffer.drawLine(100, 100, 800, 100, Color::WHITE);
			framebuffer.drawLine(50, 200, 100, 100, Color::WHITE);
			framebuffer.drawLine(850, 200, 800, 100, Color::WHITE);
			framebuffer.drawLine(80, 450, 50, 200, Color::WHITE);
			framebuffer.drawLine(800, 450, 850, 200, Color::WHITE);
			framebuffer.drawLine(80, 450, 800, 450, Color::WHITE);
			break;
		case 2:
			framebuffer.draw_ex_2(8);
			break;
		case 3:
			framebuffer.gradient(framebuffer.width, framebuffer.height, Color::RED);
			break;
		case 4:
			framebuffer.grayscale(*myimage);
			break;
		case 5:
			framebuffer.invert(*myimage);
			break;
		case 6:
			framebuffer.rotate(80, *myimage2);
			break;
		case 7:
			framebuffer.scale_ex(*myimage2, 0.4);
			break;
		case 8:
			for (int i = 0; i < num_particulas; i++) {
				framebuffer.drawCircle(particulas[i].x, particulas[i].y,particulas[i].size, Color::WHITE, TRUE);
			}
			break;
		case 9:
			framebuffer.drawing_tool(*canvas);
			break;
	}
}

//called after render
void Application::update(double seconds_elapsed)
{
	for (int k = 0; k < num_particulas; k++) {//Para cada particula modificamos su posicion x e y para que bajen haciendo un sinus. Los if's son para que las particulas no se salgan de la pantalla y exploten.
		int sinus = (7 * sin(time * particulas[k].speed));
		if ((particulas[k].y - particulas[k].speed) > (particulas[k].size + 1) && (particulas[k].x + sinus) > (particulas[k].size + 1) && (particulas[k].x + sinus) < (window_width - particulas[k].size - 1)) {
			particulas[k].x += sinus;
			particulas[k].y -= particulas[k].speed;

		}
		else {
			particulas[k].y = (float)randomValue() * (window_height - 2*particulas[k].size - 1)+ particulas[k].size + 1;
			particulas[k].x = (float)randomValue() * (window_width - particulas[k].size - 1);
		}
	}

	//to see all the keycodes: https://wiki.libsdl.org/SDL_Keycode
	if (keystate[SDL_SCANCODE_SPACE]) //if key space is pressed
	{

	}



	//to read mouse position use mouse_position
}

//keyboard press event 
void Application::onKeyDown( SDL_KeyboardEvent event )
{
	//to see all the keycodes: https://wiki.libsdl.org/SDL_Keycode
	switch(event.keysym.scancode)
	{
		case SDL_SCANCODE_ESCAPE:
			exit(0); 
			break; //ESC key, kill the app		
		case SDL_SCANCODE_0:
			render_mode = 0;
			break;
		case SDL_SCANCODE_1:
			render_mode = 1;
			break;
		case SDL_SCANCODE_2:
			render_mode = 2;
			break;
		case SDL_SCANCODE_3:
			render_mode = 3;
			break;
		case SDL_SCANCODE_4:
			render_mode = 4;
			break;
		case SDL_SCANCODE_5:
			render_mode = 5;
			break;
		case SDL_SCANCODE_6:
			render_mode = 6;
			break;
		case SDL_SCANCODE_7:
			render_mode = 7;
			break;
		case SDL_SCANCODE_8:
			render_mode = 8;
			break;
		case SDL_SCANCODE_9:
			render_mode = 9;
			break;

	}
}

//keyboard key up event 
void Application::onKeyUp(SDL_KeyboardEvent event)
{
	//...
}

//mouse button event
void Application::onMouseButtonDown( SDL_MouseButtonEvent event )
{
	if (event.button == SDL_BUTTON_LEFT) //left mouse pressed
	{

		//if you read mouse position from the event, careful, Y is reversed, use mouse_position instead
	}
}

void Application::onMouseButtonUp( SDL_MouseButtonEvent event )
{
	if (event.button == SDL_BUTTON_LEFT) //left mouse unpressed
	{
	}
}

//when the app starts
void Application::start()
{
	std::cout << "launching loop..." << std::endl;
	launchLoop(this);
}
