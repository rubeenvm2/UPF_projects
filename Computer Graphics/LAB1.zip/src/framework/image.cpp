#include "image.h"


Image::Image() {
	width = 0; height = 0;
	pixels = NULL;
}

Image::Image(unsigned int width, unsigned int height)
{
	this->width = width;
	this->height = height;
	pixels = new Color[width*height];
	memset(pixels, 0, width * height * sizeof(Color));
}

//copy constructor
Image::Image(const Image& c) {
	pixels = NULL;

	width = c.width;
	height = c.height;
	if(c.pixels)
	{
		pixels = new Color[width*height];
		memcpy(pixels, c.pixels, width*height*sizeof(Color));
	}
}

//assign operator
Image& Image::operator = (const Image& c)
{
	if(pixels) delete pixels;
	pixels = NULL;

	width = c.width;
	height = c.height;
	if(c.pixels)
	{
		pixels = new Color[width*height*sizeof(Color)];
		memcpy(pixels, c.pixels, width*height*sizeof(Color));
	}
	return *this;
}

Image::~Image()
{
	if(pixels) 
		delete pixels;
}



//change image size (the old one will remain in the top-left corner)
void Image::resize(unsigned int width, unsigned int height)
{
	Color* new_pixels = new Color[width*height];
	unsigned int min_width = this->width > width ? width : this->width;
	unsigned int min_height = this->height > height ? height : this->height;

	for(unsigned int x = 0; x < min_width; ++x)
		for(unsigned int y = 0; y < min_height; ++y)
			new_pixels[ y * width + x ] = getPixel(x,y);

	delete pixels;
	this->width = width;
	this->height = height;
	pixels = new_pixels;
}

//change image size and scale the content
void Image::scale(unsigned int width, unsigned int height)
{
	Color* new_pixels = new Color[width*height];

	for(unsigned int x = 0; x < width; ++x)
		for(unsigned int y = 0; y < height; ++y)
			new_pixels[ y * width + x ] = getPixel((unsigned int)(this->width * (x / (float)width)), (unsigned int)(this->height * (y / (float)height)) );

	delete pixels;
	this->width = width;
	this->height = height;
	pixels = new_pixels;
}

Image Image::getArea(unsigned int start_x, unsigned int start_y, unsigned int width, unsigned int height)
{
	Image result(width, height);
	for(unsigned int x = 0; x < width; ++x)
		for(unsigned int y = 0; y < height; ++y)
		{
			if( (x + start_x) < this->width && (y + start_y) < this->height) 
				result.setPixel( x, y, getPixel(x + start_x,y + start_y) );
		}
	return result;
}
void Image::drawRectangle(unsigned int x, unsigned int y, unsigned int w, unsigned int h, const Color color, bool fill)
{
	if (fill) {
		//Recorremos con los dos for las dimensiones del cuadrado y pintamos todo el interior porque el fill es true
		for (int i = x; i < (x + w); i++) {
			for (int j = y; j < (y + h); j++) {
				setPixel(i, j, color);
			}
		}
	}
	else {
		//Recorremos con los dos for los bordes de las dimensiones del cuadrado y  NO pintamos todo el interior porque el fill es false
		for (int i = x; i < (x + w); i++) {
			setPixel(i, y, color);
			setPixel(i, y+h-1, color);
		}
		for (int j = y + 1; j < y + h - 1; j++) {
			setPixel(x, j, color);
			setPixel(x+w-1, j, color);
		}
	}

	
}
void Image::drawLine( int x, int y, int x2, int y2, Color color)
{
	//Miramos si la linea es horizontal y simplemente avanzamos en el sentido de les y's
	if (x == x2) {
		for (int y1 = y; y1 < y2; y1++) {
			setPixel(x, y1, color);
		}
	}
	//Miramos si la linea es vertical y simplemente avanzamos en el sentido de les x's
	else if (y == y2) {
		for (int x1 = x; x1 < x2; x1++) {
			setPixel(x1, y, color);
		}
	}
	//En caso que la linea sea diagonal
	else{
		//Si la x es mayor a x2, quiere decir que la linea es en sentido negativo por asi decirlo y swapeamos la x y la y
		if (x > x2) {
			std::swap(x, x2);
			std::swap(y, y2);
		}
		//Calculamos la ecuacion de la recta y luego dibujamos en el for
		float m = (float)(y2-y) / (float)(x2-x);
		float b = y - m * x;
		int y1 = y;
		for (int x1 = x; x1 < x2; x1++) {
			y1 = round(m * x1 + b);
			setPixel(x1, y1, color);
		}
	}
}


void Image::drawCircle(unsigned int x, unsigned int y, unsigned int r, const Color color, bool fill)
{
	//Recorremos i y j mientras lo que dibujemos sea menor o igual al radio y dibujamos en los 4 cuadrantes
	for (int i = 0; i <= r; i++) {
		for (int j = 0; j <= r; j++) {
			if (sqrt(i * i + j * j) <= r & fill) {
				setPixel(x + i, y + j, color);//Cuatro cuadrantes
				setPixel(x - i, y + j, color);
				setPixel(x + i, y - j, color);
				setPixel(x - i, y - j, color);
			}
			//En caso que el fill sea false, dibujamos solo en el borde del circulo
			else if (sqrt(i * i + j * j) < r & sqrt(i * i + j * j) > (r-1) & fill == false) {
				setPixel(x + i, y + j, color);
				setPixel(x - i, y + j, color);
				setPixel(x + i, y - j, color);
				setPixel(x - i, y - j, color);
			}
		}
	}
}

void Image::draw_ex_2(unsigned int n) {
	//Calculamos el tama�o de los rectangulos
	int width_rectangles = width / n;
	int height_rectangles = height / n;
	//Recorremos todas las filas y las columnas con los dos primeros for, los siguientes dos son para dibujar cada rectangulo
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j ++) {
			for (int x = width_rectangles * i; x < width_rectangles * (i + 1); x++) {
				for (int y = height_rectangles * j; y < height_rectangles * (j + 1); y++) {
					//Aqui miramos si la suma de filas y columnas es par o impar, si es par dibujamos en blanco, si es impar lo hacemos negro
					if (fmod(i + j, 2) == 0) {
						setPixel(x, y, Color::WHITE);
					}
					else {
						setPixel(x, y, Color::BLACK);
					}
				}
			}

		}
	}
}

void Image::gradient(unsigned int w, unsigned int h, Color color) {
	//Utilizamos la funcion de las slides para dibujar el gradiente
	for (int i = 0; i < w; i++) {
		for (int j = 0; j < h; j++) {
			float f = i / (float)w;
			f = f * 255;
			setPixel(i, j, Color(f, 0, 255-f));
		}
	}
}

void Image::rotate(int b, Image image)
{
	float theta = b*PI/180;//Pasamos el angulo de degree a radiantes
	//Recorremos la width y la heihgt de la imagen y usamos la formula: 
	//X2 = x*cos(B) - y*sin(B)
	//Y2 = x*sin(B) + y*cos(B)
	//Cogemos el color de x,y que luego colocaremos en las x2,y2 calculadas.
	for (int x = 0; x < image.width; x++) {
		for (int y = 0; y < image.height; y++) {
			Color pixel = image.getPixel(x, y);
			float r = x * cos(theta);
			float u = y * sin(theta);
			float t = x * sin(theta);
			float s = y * cos(theta);
			int x2 = r - u;
			int y2 = t + s;
			setPixel(x2, y2, pixel);
		}
	}
}
void Image::scale_ex(Image image, float scale) {
	//Recorremos la width y la height de la imagen y colocamos el color de los pixeles y los colocamos en x*el argumento que nos dan para escalar.
	for (int x = 0; x < image.width; x++) {
		for (int y = 0; y < image.height; y++) {
			Color pixel = image.getPixel(x, y);
			setPixel((x * scale), (y*scale), pixel);
		}
	}
}

void Image::grayscale(Image image) {
	//Ajustamos la imagen a la pantalla del framebuffer con scale
	image.scale(width, height);
	//Recorremos la imagen y para cada valor le cambiamos el color a una escala de grises con la formula sqrt((r^2+g^2+b^2)/3)
	for (int i = 0; i < image.width; i++) {
		for (int j = 0; j < image.height; j++) {
			Color pixel = image.getPixel(i, j);
			float pixel_gray = sqrt((pixel.r * pixel.r + pixel.g * pixel.g + pixel.b * pixel.b) / 3);
			setPixel(i, j, Color(pixel_gray, pixel_gray, pixel_gray));
		}
	}
}

void Image::invert(Image image) {
	//Ajustamos la imagen a la pantalla del framebuffer con scale
	image.scale(width, height);
	//Recorremos la imagen y para cada valor le cambiamos el color invirtiendolo, es decir 1-valor de cada atributo.
	for (int i = 0; i < image.width; i++) {
		for (int j = 0; j < image.height; j++) {
			Color pixel = image.getPixel(i, j);
			pixel.r = 1-pixel.r;
			pixel.g = 1-pixel.g;
			pixel.b = 1-pixel.b;
			setPixel(i, j, pixel);
		}
	}
}
void Image::drawing_tool(Image image) {
	//image.scale(width, height);
	fill(Color::WHITE);
	//TOOLBAR(canvas)
	for (int i = 0; i < image.width; i++) {
		for (int j = height-image.height; j < height ; j++) {
			Color pixel = image.getPixel(i,height-j);
			setPixel(i, j, pixel);
		}
	}
}
void Image::flipX()
{
	for(unsigned int x = 0; x < width * 0.5; ++x)
		for(unsigned int y = 0; y < height; ++y)
		{
			Color temp = getPixel(width - x - 1, y);
			setPixel( width - x - 1, y, getPixel(x,y));
			setPixel( x, y, temp );
		}
}

void Image::flipY()
{
	for(unsigned int x = 0; x < width; ++x)
		for(unsigned int y = 0; y < height * 0.5; ++y)
		{
			Color temp = getPixel(x, height - y - 1);
			setPixel( x, height - y - 1, getPixel(x,y) );
			setPixel( x, y, temp );
		}
}


//Loads an image from a TGA file
bool Image::loadTGA(const char* filename)
{
	unsigned char TGAheader[12] = {0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	unsigned char TGAcompare[12];
	unsigned char header[6];
	unsigned int bytesPerPixel;
	unsigned int imageSize;

	FILE * file = fopen(filename, "rb");
   	if ( file == NULL || fread(TGAcompare, 1, sizeof(TGAcompare), file) != sizeof(TGAcompare) ||
		memcmp(TGAheader, TGAcompare, sizeof(TGAheader)) != 0 ||
		fread(header, 1, sizeof(header), file) != sizeof(header))
	{
		std::cerr << "File not found: " << filename << std::endl;
		if (file == NULL)
			return NULL;
		else
		{
			fclose(file);
			return NULL;
		}
	}

	TGAInfo* tgainfo = new TGAInfo;
    
	tgainfo->width = header[1] * 256 + header[0];
	tgainfo->height = header[3] * 256 + header[2];
    
	if (tgainfo->width <= 0 || tgainfo->height <= 0 || (header[4] != 24 && header[4] != 32))
	{
		std::cerr << "TGA file seems to have errors or it is compressed, only uncompressed TGAs supported" << std::endl;
		fclose(file);
		delete tgainfo;
		return NULL;
	}
    
	tgainfo->bpp = header[4];
	bytesPerPixel = tgainfo->bpp / 8;
	imageSize = tgainfo->width * tgainfo->height * bytesPerPixel;
    
	tgainfo->data = new unsigned char[imageSize];
    
	if (tgainfo->data == NULL || fread(tgainfo->data, 1, imageSize, file) != imageSize)
	{
		if (tgainfo->data != NULL)
			delete tgainfo->data;
            
		fclose(file);
		delete tgainfo;
		return false;
	}

	fclose(file);

	//save info in image
	if(pixels)
		delete pixels;

	width = tgainfo->width;
	height = tgainfo->height;
	pixels = new Color[width*height];

	//convert to float all pixels
	for(unsigned int y = 0; y < height; ++y)
		for(unsigned int x = 0; x < width; ++x)
		{
			unsigned int pos = y * width * bytesPerPixel + x * bytesPerPixel;
			this->setPixel(x , height - y - 1, Color( tgainfo->data[pos+2], tgainfo->data[pos+1], tgainfo->data[pos]) );
		}

	delete tgainfo->data;
	delete tgainfo;

	return true;
}

// Saves the image to a TGA file
bool Image::saveTGA(const char* filename)
{
	unsigned char TGAheader[12] = {0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0};

	FILE *file = fopen(filename, "wb");
	if ( file == NULL )
	{
		fclose(file);
		return false;
	}

	unsigned short header_short[3];
	header_short[0] = width;
	header_short[1] = height;
	unsigned char* header = (unsigned char*)header_short;
	header[4] = 24;
	header[5] = 0;

	//tgainfo->width = header[1] * 256 + header[0];
	//tgainfo->height = header[3] * 256 + header[2];

	fwrite(TGAheader, 1, sizeof(TGAheader), file);
	fwrite(header, 1, 6, file);

	//convert pixels to unsigned char
	unsigned char* bytes = new unsigned char[width*height*3];
	for(unsigned int y = 0; y < height; ++y)
		for(unsigned int x = 0; x < width; ++x)
		{
			Color c = pixels[(height-y-1)*width+x];
			unsigned int pos = (y*width+x)*3;
			bytes[pos+2] = c.r;
			bytes[pos+1] = c.g;
			bytes[pos] = c.b;
		}

	fwrite(bytes, 1, width*height*3, file);
	fclose(file);
	return true;
}

#ifndef IGNORE_LAMBDAS

//you can apply and algorithm for two images and store the result in the first one
//forEachPixel( img, img2, [](Color a, Color b) { return a + b; } );
template <typename F>
void forEachPixel(Image& img, const Image& img2, F f) {
	for(unsigned int pos = 0; pos < img.width * img.height; ++pos)
		img.pixels[pos] = f( img.pixels[pos], img2.pixels[pos] );
}

#endif